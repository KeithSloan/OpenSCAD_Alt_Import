filepath_forum='C:\\Users\\mconsidine\\Downloads\\FreeCAD\\DXFtests\\forum\\'
list_forum=["044-005636_Schaltschrank Bedienseite.dxf",
  "Altair8800.dxf",
  "Body_to_DXF.dxf",
  "CBL1494_Purged.dxf",
  "cutting plan.dxf",
  "drache_fackel_V2.dxf",
  "drache_fackel_V2_R14_Closed.dxf",
  "export.dxf",
  "G443_G413_7.dxf",
  "plaque-sketch-outline.dxf",
  "plaque-sketch-outlineLightburn.dxf",
  "strut.dxf",
  "Wires_to_DXF.dxf"]
